# NYTimesProduct
Cornell Tech product studio challenge in collaboration with The NY Times.
